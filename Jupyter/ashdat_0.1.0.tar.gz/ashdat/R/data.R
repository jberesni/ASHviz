#' ASHDUMP1: First ASH dump data frame
#'
#' Data frame constructed from old ASH dumps from EMAIL database.
#' Several columns added for data visualizations.
#'
#' DB version: 10.2
#' 4-node RAC
#' cores?
#'
#'
"ASHDUMP1"

#' EventNames11g
#'
#' This function returns a data frame of V$EVENT_NAME
#' sourced from an 11g database.
#'
#' columns:
#' EVENT_ID      factor
#' EVENTNAME     chr
#' WAITCLASS_ID  factor
#' WAITCLASS     chr
#'
"EventNames11g"
